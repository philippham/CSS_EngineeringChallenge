﻿using System.Collections.Concurrent;
using Newtonsoft.Json;

namespace CSS_EngineeringChallenge
{
	public class OrderEventBus
	{
		static BlockingCollection<Order> dataItems = new BlockingCollection<Order>();
		private static OrderStorage orderStore;

        static OrderEventBus()
        {
			orderStore = new OrderStorage();
		}

		public static Task Produce(int ordersPerSecond)
		{
			while(ordersPerSecond > 0)
			{
				var order = orderStore.getNextOrder();
				if (order != null)
				{
					Console.WriteLine("Received Order: " + JsonConvert.SerializeObject(order));
					dataItems.Add(orderStore.getNextOrder());
				}
				else
				{
                    Console.WriteLine("No more orders.");
				}
				ordersPerSecond--;
			}
			Thread.Sleep(1000);
			return Task.CompletedTask;
		}


		public static async Task<Order> Consume()
		{
            try
            {
				return await Task.FromResult(dataItems.Take());
			}
            catch (Exception ex)
            {
				return null;
            }
		}
	}
}

