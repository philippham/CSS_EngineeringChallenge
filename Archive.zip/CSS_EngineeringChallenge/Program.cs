﻿
namespace CSS_EngineeringChallenge
{
    class Program
    {
        static Configuration config = new Configuration()
        {
            OrderPerSecond = 2,
            NumberOfCourier = 5
        };

        public static Task Main()
        {
            var runner = new MyRunner(config);

            while (true)
            {
                try {
                    runner.Run();
                }
                catch {
                    throw;
                }
            }
        }
    }
}
