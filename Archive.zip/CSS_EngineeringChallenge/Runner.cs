﻿using Newtonsoft.Json;

namespace CSS_EngineeringChallenge
{
	public class MyRunner
    {
        private readonly Configuration config;
        private readonly ShelfBus shelfBus;
        private readonly CourierConsumer courierConsumer;


        public MyRunner(Configuration config)
		{
            this.config = config;
            this.shelfBus = new ShelfBus();
            this.courierConsumer = new CourierConsumer(config.NumberOfCourier);
        }

        public async Task Run()
        {
            try
            {
                OrderEventBus.Produce(config.OrderPerSecond);
                Task.Factory.StartNew(CookOrders);
                Task.Factory.StartNew(DispatchCourier);
            }
            catch (Exception er)
            {
                Environment.Exit(0);
            }
        }

        public async Task CookOrders()
        {
            var cookedOrder = await OrderEventBus.Consume();
            while (cookedOrder != null)
            {
                shelfBus.Produce(cookedOrder);
                cookedOrder = await OrderEventBus.Consume();
            }
        }

        public async Task DispatchCourier()
        {
            var onShelfOrder = shelfBus.Consume();
            while (onShelfOrder != null)
            {
                await this.courierConsumer.Dispatch(onShelfOrder);
                onShelfOrder = shelfBus.Consume();
            }
        }
    }
}

