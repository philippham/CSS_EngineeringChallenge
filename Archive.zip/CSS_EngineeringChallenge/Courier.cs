﻿namespace CSS_EngineeringChallenge
{
	public class Courier
	{
        public int id { get; set; }
        public Order myOrder { get; set; }
    }
}

