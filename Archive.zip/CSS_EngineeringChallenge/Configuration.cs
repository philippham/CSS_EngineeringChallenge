﻿using System;
namespace CSS_EngineeringChallenge
{
	public class Configuration
	{
        public int OrderPerSecond { get; set; }
        public int NumberOfCourier { get; set; }
    }
}

