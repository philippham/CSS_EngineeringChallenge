﻿using System;

namespace CSS_EngineeringChallenge
{
	public class Order
	{
        public string id { get; set; }
        public string name { get; set; }
        public string temp { get; set; }
        public double shelfLife { get; set; }
        public double decayRate { get; set; }
    }
}

