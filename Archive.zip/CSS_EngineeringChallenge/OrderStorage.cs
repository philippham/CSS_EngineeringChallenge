﻿using System.Reflection;
using Newtonsoft.Json;

namespace CSS_EngineeringChallenge
{
	public class OrderStorage
	{
		private readonly Queue<Order> orders;
		private readonly string dbConnectionString;

		public OrderStorage()
		{
			dbConnectionString = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"orders.json");
            orders = JsonConvert.DeserializeObject<Queue<Order>>(File.ReadAllText(dbConnectionString));
		}

		public Order getNextOrder()
        {
			if (orders.Count != 0)
				return orders.Dequeue();
			else
				return null;
		}
	}
}