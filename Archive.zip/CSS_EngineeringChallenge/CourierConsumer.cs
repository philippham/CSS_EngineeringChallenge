﻿using System;
namespace CSS_EngineeringChallenge
{
	public class CourierConsumer
	{
		private readonly Queue<Courier> couriersQueue;

		public CourierConsumer(int numberOfCouriers)
		{
			couriersQueue = new Queue<Courier>();
			for (int i = 0; i < numberOfCouriers; i++)
			{
				couriersQueue.Enqueue(new Courier() { id = i+ 1});
			}
		}

		public async Task Dispatch(Order order)
		{
			Random rnd = new Random();
			int rand = rnd.Next(2, 6);
			Thread.Sleep(rand*1000);

			if (order != null) {
				var courier = couriersQueue.Dequeue();
				courier.myOrder = order;
				Console.WriteLine($"Courier-ID: {courier.id}, picked up an order: " + order.id);
				couriersQueue.Enqueue(courier);
			}
		}
	}
}

