﻿using System.Collections.Concurrent;

namespace CSS_EngineeringChallenge
{
	public class ShelfBus
	{
		private Queue<Order> myQueue = new Queue<Order>();

		private Dictionary<string, int> CurrentShelfCapacity = new Dictionary<string, int>() {
			{ "hot" , 0 },
			{ "cold", 0 },
			{ "frozen" , 0 },
			{ "overflow", 0 }
		};
		private Dictionary<string, int> ShelfLimit = new Dictionary<string, int>() {
			{ "hot" , 10 },
			{ "cold", 10 },
			{ "frozen" , 10 },
			{ "overflow", 15 }
		};

		public void Produce(Order cookedOrder)
		{
			/*
			if (CurrentShelfCapacity[cookedOrder.temp] == ShelfLimit[cookedOrder.temp])
			{
				if (CurrentShelfCapacity["overflow"] == ShelfLimit["overflow"])
				{
					myQueue.Dequeue();
					cookedOrder.temp = "overflow";
				}
			}
			*/
			myQueue.Enqueue(cookedOrder);
		}


		public Order Consume()
		{
			if (myQueue.Count != 0)
			{
				var order = myQueue.Dequeue();
				//CurrentShelfCapacity[order.temp] -= 1;
				return order;
			}

			return null;
		}

	}
}

